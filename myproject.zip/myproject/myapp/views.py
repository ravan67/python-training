from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect 
from . models import *
# create your viers here.

def home(request):
    if 'email' in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = CafeOwner.objects.get(user_id = uid)

        context = {
                        'uid' : uid,
                        'cid' : cid,
           }
        return render(request,"myapp/index.html",context)
    else:
        return render(request,"myapp/login.html")

def login(request):
    if 'email' in request.session:
        return redirect("home") 
        
    else:
        if request.POST:
            email = request.POST['emailname']
            password = request.POST['passwordname']

            uid=User.objects.get(email=email)
            print("--->",uid.password)
            print("---->",uid.role)
            if uid.password == password:
                if uid.role == "cafeowner":
                    cid = CafeOwner.objects.get(user_id = uid)
                    print("---> username",cid.username)
                    print("---> contact",cid.contact)
                    request.session['email'] = uid.email
                    context = {
                        'uid' : uid,
                        'cid' : cid,
                    }
                return render(request,"myapp/index.html",context)
            
            else:
                e_msg = "invalid password"
                context = {
                    'e_msg' : e_msg
                }
                return render(request,"myapp/login.html",context)
        else:
            print("------->login page referesh")
            return render(request,"myapp/login.html")

def logout(request):
    if "email" in request.session:
        del request.session['email']
        return redirect("login")
     
    else:
        return redirect("login")

def profile(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = CafeOwner.objects.get(user_id = uid)
        context = {
                        'uid' : uid,
                        'cid' : cid,
        }
        return render(request,"myapp/profile.html",context)

def cafe_password_change(request):

    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = CafeOwner.objects.get(user_id = uid)
        if request.POST:
            currentpassword = request.POST['currentpassword']
            newpassword = request.POST['newpassword']
            if uid.password == currentpassword:
                uid.password = newpassword
                uid.save()  #update
                return redirect("logout")     
        else:
            return redirect("profile")

def cafe_owner_pic_change(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = CafeOwner.objects.get(user_id = uid)
        if request.POST:
            if "pic" in request.FILES:
                pic = request.FILES['pic']
                cid.pic = pic
                cid.save()

            return redirect("profile")

def add_product(request):
    if "email" in request.session:
        print("=================================-----------------")
        uid = User.objects.get(email = request.session['email'])
        cid = CafeOwner.objects.get(user_id = uid)
        c_all = Category.objects.all() # fatch all data from table
        if request.POST:
            c_name = request.POST['category_id']
            print("---->category id",c_name)
            category_id = Category.objects.get(category_name = c_name)

            pid = Products.objects.create(
                user_id = uid,
                category_id = category_id,
                product_name = request.POST['product_name'],
                description = request.POST['description'],
                food_type = request.POST['food_type'],
                price = request.POST['price'],
                pic = request.FILES['pic'],
            )

            if pid:
                s_msg = "successfully product details added !!"

                context = {
                    'uid' : uid,  
                    'cid' : cid,
                    'c_all' : c_all,
                    's_msg' : s_msg,
                }

                return render(request,"myapp/add-product.html",context)
            
        else:
            context = {
                'uid' : uid,
                'cid' : cid,
                'c_all' : c_all,
            }

            return render(request,"myapp/add-product.html",context)

def all_product(request): 
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = CafeOwner.objects.get(user_id = uid)
        pall = Products.objects.filter(user_id = uid)
        c_all = Category.objects.all()

        context = {
            'uid' : uid,
            'cid' : cid,
            'pall' : pall,
            'c_all' : c_all,
        }

        return render(request,"myapp/all-products.html",context)

def search_product(request): 

    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = CafeOwner.objects.get(user_id = uid)

        category_id = request.POST['category_id_search']
        categoryid = Category.objects.get(category_name = category_id)

        pall = Products.objects.filter(user_id = uid, category_id = categoryid)
        c_all = Category.objects.all()
        
        context = {
            'uid' : uid,
            'cid' : cid,
            'pall' : pall,
            'c_all' : c_all,
        }

        return render(request,"myapp/all-products.html",context)

def edit_product(request,pk):
    print("======> PK",pk)  

    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        pid = Products.objects.get(id= pk)
        cid = CafeOwner.objects.get(user_id = uid)
        pall = Products.objects.filter(user_id = uid)

        context = {
            'uid' : uid,
            'cid' : cid,
            'pall': pall,
            'pid' : pid,
        }

        return render(request,"myapp/edit-product.html",context)

def updata_product(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = CafeOwner.objects.get(user_id = uid)
        pall = Products.objects.filter(user_id = uid)
        
        if request.POST:
            pid = Products.objects.get(id = request.POST['product_id'])
            if "category_id" in request.POST: 
                category_name = request.POST['category_id']
                pid.category_id = Category.objects.get(category_name = category_name) 
            pid.product_name = request.POST['product_name']
            pid.description = request.POST['description']
            pid.food_type = request.POST['food_type']
            pid.price = request.POST['price']
            if "pic" in request.FILES:
                pid.pic = request.FILES['pic']

            pid.save()

        context = {
            'uid' : uid,
            'cid' : cid,
            'pall': pall,
        }
        return render(request,"myapp/all-products.html",context)

def delete_product(request,pk):
    if "email" in request.session:
       

        pid = Products.objects.get(id = pk )

        pid.delete()

        return redirect("all-product")
