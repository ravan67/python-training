from django.db import models

# Create your models here.
class User(models.Model):
    email = models.EmailField(unique=True,max_length=30)
    password = models.CharField(max_length=30)
    role = models.CharField(max_length=30)

    def __str__(self):
        return self.email

class CafeOwner(models.Model):
    user_id = models.ForeignKey(User,on_delete=models.CASCADE)
    username = models.CharField(max_length=30)
    contact= models.CharField(max_length=30)
    cafe_name = models.CharField(max_length=30)
    cafe_address = models.TextField()
    pic = models.FileField(upload_to="media/images",default="media/pic.png")
   
    def __str__(self):
        return self.username


class Category(models.Model):
    category_name = models.CharField(max_length=60)

    def __str__(self):
        return self.category_name

class Products(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    category_id = models.ForeignKey(Category,on_delete=models.CASCADE)
    product_name = models.CharField(max_length=30)
    description = models.CharField(max_length=100)
    food_type = models.CharField(max_length=30,blank=True,null=True)
    price = models.CharField(max_length=50)
    pic = models.FileField(upload_to="media/images",default="media/images/piz.jpg")
 
    def __str__(self):
        return self.product_name


