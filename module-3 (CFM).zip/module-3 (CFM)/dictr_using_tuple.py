tuple = (('a',1),('b',2),('c',3),('d',4))
final = dict((key , value) for key , value in tuple)
print(final)