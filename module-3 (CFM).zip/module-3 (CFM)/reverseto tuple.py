#

tuple = (1,2,3,4,5,6)

print(tuple)

rev_tuple = tuple[::-1]

print(rev_tuple)