tuple= (1,2,7,5,9,4,54,65,6,8,65,6,5,65,8,56,65,6,98)
print("6 is repeated for  :", tuple.count(6))
print("65 is repeated for :", tuple.count(65))

