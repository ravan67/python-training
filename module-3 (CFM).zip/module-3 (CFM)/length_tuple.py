tuple = (1,4,5,8,6,2,54,69,65)
print(len(tuple))