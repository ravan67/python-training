# list is empty or not empty

l1 = []
l2 = [1,2,3]
len(l1)
len(l2)
if len(l1) == 0:
    print("l1 is empty")

else:
    print("l1 is not empty")

if len(l2) == 0:
    print("l2 is empty")

else:
    print("l2 is not empty")