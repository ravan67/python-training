dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

def is_key_present(x):
    if x in dict:
        print("key is present")
    else : 
        print("key is not present")
        
is_key_present(2)
is_key_present('a')