tuple = [(),(1,2),(24,36),(),(""),(''),('a','ab')]


tuple = [t for t in tuple if t ]

print(tuple)