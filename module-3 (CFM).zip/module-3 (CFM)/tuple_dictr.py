def convert(tup , di):
    di = dict(tup)
    return di

tup = [('a' , 1),('b',2),('c',3),('d',4)]
dictionary = {}
print(convert(tup , dictionary))