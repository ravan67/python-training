print("Enter the Multiple Decimal Points Comma Separate...")
dec = input("").split(",")
print("Maximum: ", max(dec))
print("Minimum: ", min(dec))