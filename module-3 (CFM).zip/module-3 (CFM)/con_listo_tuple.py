list = [1,5,15,4,5,98]
print(list)
print(type(list))
tuple = tuple(list)

print(tuple)
print(type(tuple))
