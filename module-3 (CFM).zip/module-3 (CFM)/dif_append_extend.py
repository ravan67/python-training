# append(): to add element in existing list
# extend(): to add mtltiple element in existing list

list = [1,2,3,4,5]
list.append(6)
print(list)
list.extend([7,8,9])
print(list)