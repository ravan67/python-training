a = (1,2,3,4,5,65,7,'a','b')
print(type(a))