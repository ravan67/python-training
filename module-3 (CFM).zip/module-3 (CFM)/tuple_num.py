a = (1,4,5,6,2,4)
print(tuple(a))