# will print the list object of the list

list = [1,2,3,4,5]
list.pop()
print(list)

list1 = [2,3,56,565,12]
print(list1[-1])
