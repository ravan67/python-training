tuple = (1,2)
len(tuple)

if len(tuple) > 0:
    print("element exist in a tuple")

else:
    print("element not exist in tuple")