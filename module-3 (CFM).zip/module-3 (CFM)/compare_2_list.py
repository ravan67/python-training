# to compare list we can use this symmbol '=='

l1 = [1,2,3,4,5]
l2 = [2,3,6,8,7]

l1 == l2
if l1 == l2:
    print("Equal")

else:
    print("not Equal")