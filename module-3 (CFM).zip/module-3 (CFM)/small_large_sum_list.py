l1 = [1,2,3,4,5,6,4]

print("minimum number : ", min(l1))
print("maximum number : ", max(l1))
print("sum of list    : ", sum(l1))