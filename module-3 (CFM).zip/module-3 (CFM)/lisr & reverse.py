"""
list : list is collection of data , which is mulable , orderd ,indexed

"""

list  = [1,2,3,4,5,6]
print(list[::-1])